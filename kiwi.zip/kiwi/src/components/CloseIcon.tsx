import { X } from 'react-feather'
import styled from 'styled-components'

const CloseIcon = styled(X)`
  cursor: pointer;
`

export default CloseIcon
