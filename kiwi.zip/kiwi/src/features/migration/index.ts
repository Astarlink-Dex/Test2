import { ChainId } from '../../sdk'

export const MigrationSupported = [ChainId.MAINNET, ChainId.BSC, ChainId.MATIC]
