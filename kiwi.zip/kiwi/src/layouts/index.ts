import { default as Default } from './Default'
import { default as Kashi } from './Kashi'

const Layout = { Default, Kashi }

export default Layout
