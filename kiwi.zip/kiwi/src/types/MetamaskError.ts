export default interface MetamaskError {
  code?: unknown
  message?: string
}
